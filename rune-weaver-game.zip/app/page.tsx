export default function Page() {
  return (
    <iframe
      src="/index.html"
      className="w-full h-screen border-0"
      title="CODE//REALM - Hack Reality"
    />
  )
}
